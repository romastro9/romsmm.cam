<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://aapkasmmstore.space' );
define('STYLESHEETS_URL', '//aapkasmmstore.space' );
date_default_timezone_set('Asia/Kolkata');

/* 
 ini_set("display_errors","1");
error_reporting(E_ERROR);  */  

error_reporting(0);
return [
  'db' => [
    'name'    =>  'aapkasmm_store' ,
    'host'    =>  'localhost',
    'user'    =>  'aapkasmm_store' ,
    'pass'    =>  'grg415)+2sxcv' ,
    'charset' =>  'utf8mb4'
  ]
];

?>